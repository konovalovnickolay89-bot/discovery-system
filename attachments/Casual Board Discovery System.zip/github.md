repo: konovalovnickolay89-bot/discovery-system
branch: main
path: src/components/board

## Last sync
date: 2026-07-30T08:07:24Z

### Updated in this project
- Recreated the Casual Board dashboard UI pixel-perfect as a single Design Component
- Matched dark theme tokens, IBM Plex Mono/Sans type, board-card accent system from src/styles.css
- Rebuilt Today, Media, Learning, Briefing, Machine, Hermes chat, Board settings, and Login panels with live interactions (capture, media transport, ring rotation, chat, start-fresh)

## Screen map
| Project screen | Repo files |
| --- | --- |
| Casual Board.dc.html | src/components/board/CasualBoard.tsx, HeaderBar.tsx, TodayCard.tsx, MediaCard.tsx, LearningCard.tsx, BriefingCard.tsx, MachineCard.tsx, ChatPanel.tsx, BoardSettings.tsx, LoginPanel.tsx, TagChip.tsx, ApiFailureBanner.tsx, src/styles.css, src/lib/board-types.ts, backend/app/seed.py |
